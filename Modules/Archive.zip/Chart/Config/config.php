<?php

return [
    'name' => 'Chart'
];
