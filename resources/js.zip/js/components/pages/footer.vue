<template>
    <div>

<footer class="_footer">
			<div class="container">
				<div class="row">
					<div class="col-12 col-md-12 _footer_main ">
						<p class="_footer_title">About Microjob Engine</p>

						<ul class="_footer_ul">
							<li><router-link :to="{name:'terms'}"> Terms & Privacy</router-link></li>
							<li><router-link :to="{name:'about'}">About</router-link></li>
						</ul>
						<p class="copy_right"><span class="_color">micro Engine</span>@ 2019 Microjob</p>
					</div>
				</div>

				<div class="row _footer_feb_row">
					<div class="col-12 col-md-9">
						
					</div>
					<!-- <div class="col-12 col-md-3">
						<ul class="_footer_feb">
							<li><i class="fab fa-linkedin-in"></i></li>
							<li><i class="fab fa-facebook-f"></i></li>
							<li><i class="fab fa-twitter"></i></li>
							<li><i class="fab fa-google-plus-g"></i></li>
						</ul>
					</div> -->
				</div>
			</div>
		</footer>

    </div>


</template>
