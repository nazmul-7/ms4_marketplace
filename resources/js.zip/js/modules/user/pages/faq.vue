<template>
    <div>
        <div class="container">
            <div class="_box_shadow2 terms ">
                <p class="_title3">FAQ</p>

                <h3>What is Ms4.co known for?</h3>
                <p>
                    Ms4.co is an online marketplace that offers opportunities for independent health and beauty providers to expand their client reach. Our website will exclusively: list, advertise and promote your services and connect you with interested buyers across London. It doesn’t mater whether you’re independent or part of team – buyers will find your business and be able to make an online booking via our website.
                </p>
                <h3>What is our purpose?</h3>
                <p>
                    Our aim is to assist independent mobile health and beauty providers to promote their craft while making it easy and cost-effective for potential clients to book their services online.
                </p>
                <h3>What benefits will I enjoy on Ms4.co?</h3>
                <p>On our marketplace, users will enjoy exclusive offers that includes:</p>

                <ul>
                    <li>Communicating with your prospective clients.</li>
                    <li>Scheduling and receiving bookings on our reliable online booking system.</li>
                    <li>Receiving positive reviews and feedbacks from clients to boost seller profile and reputation.    </li>
                </ul>

                <h3>
                    As a seller, where can I offer my services?
                </h3>
                <p>When you list services on Ms4.co. we will promote your business to clients across London. This means that your business profile will be made visible to many potential clients.</p>

                <h3>How can I be a seller on Ms4.co?</h3>
                <p>
                    To join, please click the signup button to register with your email and follow the instructions to create your profile. Once successfully registered give details about your business and then start receiving interest from your local area.
                </p>

                <h3>
                    Who can sell on Ms4.co?
                </h3>
                <p>Ms4.co allows both individual, jointly owned or group service providers to register and provide services under the various sections on our website.</p>

                <h3>What kind of services I can provide?</h3>
                <p>fter creating a profile, a seller on Ms4.co can offer professional services for:</p>
                <ul>
                    <li>Hair</li>
                    <li>Make-up</li>
                    <li>Facials</li>
                    <li>Manicure and pedicure</li>
                    <li>Body waxing</li>
                    <li>Tanning</li>
                    <li>Body Massage</li>
                    <li>Events planning</li>
                    <li>And lots more</li>
                </ul>
                <h3>Will I have to pay a fee to advertise my services?</h3>

                <p>No. All these interesting features on Ms4.co are meant to be enjoyed without paying a fee. Everything is FREE.</p>

                <h3>What are the rules guiding ads posting?</h3>
                <p>We will review each profile before it goes live. Inappropriate posts that contain misleading, offensive or sexual contents which violate our Terms and Conditions will be deleted. We reserve the right to delete such contents.

                    Also, we will verify all provided contact details to be sure that they belong to you. Details such as phone number, e-mail, shop address advertisement pictures. False profile details will not be accepted.
                </p>
                <br>
                <br>
          
                <p>Read more about our terms and conditions.</p>
                <h3>Why is my advertisement deleted?</h3>
                <p>If we believe that our terms and conditions have been violated, your advert will be deleted.</p>
                <h3>
                    How should I charge my clients?
                </h3>
                <p>We do not offer online transactions. It is your sole responsibility to charge your clients for your services.</p>
                <h3>Can I book a seller ahead of time?</h3>
                <p>You can pre-book your favourite service provider on a date and time which is convenient for both parties.</p>

                <h3>Do you still have a question?</h3>
                <p>If you have anymore questions, feel free to open a support ticket by using the Contact us form. Our customer care agents will get in contact with you with in a short time.</p>
            </div>
        </div>
    </div>
</template>
