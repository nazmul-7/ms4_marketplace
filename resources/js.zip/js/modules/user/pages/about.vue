<template>
    <div>
        <div class="container">
            <div class="_box_shadow2 terms ">
                <p class="_title3">About</p>

                <p>Ms4. Co is a fast rising marketplace for Beauty and Healthcare enthusiast in London. Our online platform allows independent, individual and groups of beauty and healthcare experts who offer mobile services to: list, advertise, promotes and ultimately access bookings from interested clients in your local area.  In a bid to help your business grow, Ms4 offers you the opportunity to promote your services and connect with prospective clients for FREE.

                        We at Ms4.co are committed to exposing your services to a large number of interested clients by building your online reputation in the beauty and healthcare industry.

                        Clients will be able to explore a community of talented beauty and healthcare experts to find the right professional for all your healthcare and beauty needs. Our main goal is to give you and exceptional, online booking experience to save you the stress of going to the spa.

                        It doesn’t matter whether your busy schedule does not avail you the opportunity to visit a spa or beauty parlour. On Ms4.co, you can have the luxury of booking a healthcare specialist who’s ready to come to your home, hotel or office.

                        What’s more, you’ll find everything you need on the site. Get in touch with our beauty experts today – enjoy the affordable services that are on offer for you.
                </p>
      

             
            </div>
        </div>
    </div>
</template>
