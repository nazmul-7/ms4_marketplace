<template>
    <div>
        <h1>This is wow for sure ok</h1>
        
 
    </div>
</template>

<script>
export default {
    data(){
        return{

        }
    },
    methods:{


    }
}
</script>

