export default {
   
    state: {
        testModuleNumber: 34344,
        //  tabFlag:''
    },
    getters: {
        // getFlag(state) {
        //     return state.tabFlag
        // }
    },
    mutations: {
        // setFlag: (state, payload) => {
        //     state.tabFlag = payload;
        // },
    },
    actions: {
        // setFlag: (context, payload) => {
        //     context.commit('setFlag', payload)
        // },
    }
}